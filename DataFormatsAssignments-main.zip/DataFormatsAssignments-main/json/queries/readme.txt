query-1-1.jq: Return all movies released after the year 2010, showing their id, title, and release year.

query-1-2.jq: Group movies by their producing studio, and for each studio, list its id, name, and titles of all movies it produced.

query-1-3.jq: Group movies by director and count how mant movies each director has in the data and return a list of their movies.

query-1-4.jq: Return the list of countries that have at least one studio with a movie in the data.